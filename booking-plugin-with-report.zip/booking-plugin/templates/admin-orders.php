<?php
if (!defined('ABSPATH')) exit;
global $wpdb;

// Xử lý cập nhật trạng thái
if (isset($_POST['update_status']) && check_admin_referer('update_order_status')) {
    $order_id = intval($_POST['order_id']);
    $new_status = sanitize_text_field($_POST['status']);
    
    $updated = $wpdb->update(
        $wpdb->prefix . 'bookings',
        array('status' => $new_status, 'updated_at' => current_time('mysql')),
        array('id' => $order_id)
    );
    
    if ($updated) {
        echo '<div class="notice notice-success"><p>Đã cập nhật trạng thái đơn hàng!</p></div>';
    }
}

// Xử lý xóa đơn hàng
if (isset($_GET['delete']) && check_admin_referer('delete_order_' . $_GET['delete'])) {
    $order_id = intval($_GET['delete']);
    $wpdb->delete($wpdb->prefix . 'bookings', array('id' => $order_id));
    echo '<div class="notice notice-success"><p>Đã xóa đơn hàng!</p></div>';
}

// Lấy danh sách đơn hàng
$orders = $wpdb->get_results("
    SELECT b.*, d.full_name as driver_name 
    FROM {$wpdb->prefix}bookings b
    LEFT JOIN {$wpdb->prefix}drivers d ON b.driver_id = d.id
    ORDER BY b.created_at DESC 
    LIMIT 100
");

// Thống kê
$stats = array(
    'total' => $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}bookings"),
    'pending' => $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}bookings WHERE status = 'pending'"),
    'confirmed' => $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}bookings WHERE status = 'confirmed'"),
    'completed' => $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}bookings WHERE status = 'completed'"),
    'cancelled' => $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}bookings WHERE status = 'cancelled'")
);
?>

<div class="wrap">
    <h1>📋 Quản Lý Đơn Hàng</h1>
    
    <!-- Thống kê nhanh -->
    <div class="order-stats">
        <div class="stat-box">
            <div class="stat-number"><?php echo $stats['total']; ?></div>
            <div class="stat-label">Tổng đơn</div>
        </div>
        <div class="stat-box stat-pending">
            <div class="stat-number"><?php echo $stats['pending']; ?></div>
            <div class="stat-label">Chờ xử lý</div>
        </div>
        <div class="stat-box stat-confirmed">
            <div class="stat-number"><?php echo $stats['confirmed']; ?></div>
            <div class="stat-label">Đã xác nhận</div>
        </div>
        <div class="stat-box stat-completed">
            <div class="stat-number"><?php echo $stats['completed']; ?></div>
            <div class="stat-label">Hoàn thành</div>
        </div>
        <div class="stat-box stat-cancelled">
            <div class="stat-number"><?php echo $stats['cancelled']; ?></div>
            <div class="stat-label">Đã hủy</div>
        </div>
    </div>
    
    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th style="width: 100px;">Mã Đơn</th>
                <th>Khách Hàng</th>
                <th>Tuyến Đường</th>
                <th>Loại Xe</th>
                <th>Thời Gian</th>
                <th style="width: 100px;">Giá</th>
                <th style="width: 150px;">Trạng Thái</th>
                <th style="width: 120px;">Thao Tác</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($orders): ?>
                <?php foreach ($orders as $order): ?>
                    <tr>
                        <td><strong><?php echo esc_html($order->booking_code); ?></strong></td>
                        <td>
                            <strong><?php echo esc_html($order->customer_name); ?></strong><br>
                            <small>📞 <?php echo esc_html($order->customer_phone); ?></small>
                            <?php if ($order->driver_name): ?>
                                <br><small>🚗 <?php echo esc_html($order->driver_name); ?></small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <small>
                                <strong>Từ:</strong> <?php echo esc_html(substr($order->from_location, 0, 40)); ?><br>
                                <strong>Đến:</strong> <?php echo esc_html(substr($order->to_location, 0, 40)); ?>
                                <?php if ($order->distance): ?>
                                    <br><strong>Khoảng cách:</strong> <?php echo number_format($order->distance, 1); ?> km
                                <?php endif; ?>
                            </small>
                        </td>
                        <td>
                            <?php echo esc_html($order->car_type); ?>
                            <?php if ($order->is_round_trip): ?>
                                <br><small>🔄 2 chiều</small>
                            <?php endif; ?>
                            <?php if ($order->has_vat): ?>
                                <br><small>📄 VAT</small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <small><?php echo date('d/m/Y H:i', strtotime($order->trip_datetime)); ?></small><br>
                            <small class="text-muted">Đặt: <?php echo date('d/m/Y H:i', strtotime($order->created_at)); ?></small>
                        </td>
                        <td><strong><?php echo number_format($order->price); ?>đ</strong></td>
                        <td>
                            <form method="post" class="status-form" style="margin: 0;">
                                <?php wp_nonce_field('update_order_status'); ?>
                                <input type="hidden" name="update_status" value="1">
                                <input type="hidden" name="order_id" value="<?php echo $order->id; ?>">
                                <select name="status" class="status-select status-<?php echo esc_attr($order->status); ?>" onchange="this.form.submit()">
                                    <option value="pending" <?php selected($order->status, 'pending'); ?>>Chờ xử lý</option>
                                    <option value="confirmed" <?php selected($order->status, 'confirmed'); ?>>Đã xác nhận</option>
                                    <option value="assigned" <?php selected($order->status, 'assigned'); ?>>Đã phân xe</option>
                                    <option value="in_progress" <?php selected($order->status, 'in_progress'); ?>>Đang thực hiện</option>
                                    <option value="completed" <?php selected($order->status, 'completed'); ?>>Hoàn thành</option>
                                    <option value="cancelled" <?php selected($order->status, 'cancelled'); ?>>Đã hủy</option>
                                </select>
                            </form>
                        </td>
                        <td>
                            <a href="#" class="button button-small view-order" data-id="<?php echo $order->id; ?>">Xem</a>
                            <a href="?page=booking-orders&delete=<?php echo $order->id; ?>&_wpnonce=<?php echo wp_create_nonce('delete_order_' . $order->id); ?>" 
                               class="button button-small" 
                               onclick="return confirm('Bạn có chắc muốn xóa đơn hàng này?')">Xóa</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="8" style="text-align: center; padding: 40px;">
                    <p style="font-size: 16px; color: #666;">Chưa có đơn hàng nào</p>
                </td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<style>
.order-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 15px;
    margin: 20px 0;
}

.stat-box {
    background: #fff;
    border-radius: 8px;
    padding: 20px;
    text-align: center;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    border-left: 4px solid #2271b1;
}

.stat-box.stat-pending {
    border-left-color: #f0ad4e;
}

.stat-box.stat-confirmed {
    border-left-color: #5bc0de;
}

.stat-box.stat-completed {
    border-left-color: #5cb85c;
}

.stat-box.stat-cancelled {
    border-left-color: #d9534f;
}

.stat-number {
    font-size: 32px;
    font-weight: bold;
    color: #2271b1;
    margin-bottom: 5px;
}

.stat-label {
    font-size: 13px;
    color: #666;
    text-transform: uppercase;
}

.status-select {
    width: 100%;
    padding: 5px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: bold;
    border: 2px solid #ddd;
}

.status-select.status-pending {
    background: #fff3cd;
    color: #856404;
    border-color: #ffc107;
}

.status-select.status-confirmed {
    background: #d1ecf1;
    color: #0c5460;
    border-color: #17a2b8;
}

.status-select.status-assigned {
    background: #cce5ff;
    color: #004085;
    border-color: #007bff;
}

.status-select.status-in_progress {
    background: #e7e7ff;
    color: #383d41;
    border-color: #6c757d;
}

.status-select.status-completed {
    background: #d4edda;
    color: #155724;
    border-color: #28a745;
}

.status-select.status-cancelled {
    background: #f8d7da;
    color: #721c24;
    border-color: #dc3545;
}

.text-muted {
    color: #999;
}

.wp-list-table td {
    vertical-align: top;
}
</style>

<script>
jQuery(document).ready(function($) {
    // View order details (có thể mở rộng sau)
    $('.view-order').on('click', function(e) {
        e.preventDefault();
        var orderId = $(this).data('id');
        alert('Xem chi tiết đơn hàng #' + orderId + '\n(Tính năng đang phát triển)');
    });
});
</script>
